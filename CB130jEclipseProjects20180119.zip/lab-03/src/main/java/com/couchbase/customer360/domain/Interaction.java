package com.couchbase.customer360.domain;


public class Interaction extends Entity {
	private String customerId;

	public String getCustomerId() {
		return customerId;
	}
}